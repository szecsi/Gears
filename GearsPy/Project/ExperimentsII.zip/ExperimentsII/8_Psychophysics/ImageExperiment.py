class ImageExperiment(DefaultExperiment) : 
    def boot(self, frameRateDivisor=1):
        super().boot( frameRateDivisor=frameRateDivisor )
        
  