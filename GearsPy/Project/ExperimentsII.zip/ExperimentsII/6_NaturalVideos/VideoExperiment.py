class VideoExperiment(DefaultExperiment) : 
    def boot(self, frameRateDivisor=2):
        super().boot( frameRateDivisor=frameRateDivisor )

  