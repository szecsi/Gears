import Gears as gears
import math

RaiseSignal = gears.RaiseSignal
ClearSignal = gears.ClearSignal
RaiseAndClearSignal = gears.RaiseAndClearSignal
StartMeasurement = gears.StartMeasurement
EndMeasurement = gears.EndMeasurement
